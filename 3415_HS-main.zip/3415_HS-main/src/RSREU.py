import json
from cards import *

print(cards_list)
print(type(cards_e["ram"]) == Item)